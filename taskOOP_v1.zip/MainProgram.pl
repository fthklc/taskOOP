#!/usr/bin/perl -w

use strict;
use warnings;
use POSIX;

use lib "/home/fatihk/Desktop/taskOOP/";
use PersonDataController;
no lib "/home/fatihk/Desktop/taskOOP/";

RunPeopleDataController();




=begin comment
#!/usr/bin/perl -w

use strict;
use warnings;
use POSIX;


my %h_people;
my $s_name;
my $s_surname;
my $s_birthday;
my $i_ID;
my $i_entry2;
my $s_searchkey;
my $i_counter;
my $s_key;
my $i_entry;
=cut


